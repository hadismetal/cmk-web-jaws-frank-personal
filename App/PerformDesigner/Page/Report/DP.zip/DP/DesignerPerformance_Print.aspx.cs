﻿using System;
using System.Linq;
using System.Web.UI.WebControls;
using System.Data;

public partial class Page_Report_DP_DesignerPerformance_Print : System.Web.UI.Page
{
    Map_DB db = new Map_DB();
    protected void Page_Load(object sender, EventArgs e)
    {
        App.Protect();
        App.ProtectRole(Role.Manager);

        if (!IsPostBack)
        {
            fillTable(sender, e);
            fillHeader();
        }
    }
    protected void fillHeader()
    {

        var rs = from p in db.StockProductDJ
                 where p.ReturnProduct == false && p.StatusPenjualan == 0
                 select p;
        var rsC = from p in db.CharProductCategory select p;
        var rsI = from p in db.CharProductItem select p;
        var rsL = from p in db.CharProductLevel select p;
        var rsB = from p in db.StockActualDJ select p;

        if (Convert.ToInt32(Request.QueryString["cabang"]) > 0) { var v_cab = rsB.SingleOrDefault(p => p.IDLokasi == Convert.ToInt32(Request.QueryString["cabang"]) && p.TipeLokasi == Convert.ToInt32(Request.QueryString["tipe"])); cabang.InnerText = v_cab.NamaLokasi; } else { cabang.InnerText = "Semua"; }
        if (Convert.ToInt32(Request.QueryString["productcategory"]) > 0) { var v_cat = rsC.SingleOrDefault(p => p.ID == Convert.ToInt32(Request.QueryString["productcategory"])); category.InnerText = v_cat.Nama; } else { category.InnerText = "Semua"; }
        if (Convert.ToInt32(Request.QueryString["productitem"]) > 0) { var v_itm = rsI.SingleOrDefault(p => p.ID == Convert.ToInt32(Request.QueryString["productitem"])); item.InnerText = v_itm.Nama; } else { item.InnerText = "Semua"; }
        if (Convert.ToInt32(Request.QueryString["productlevel"]) > 0) { var v_lvl = rsL.SingleOrDefault(p => p.ID == Convert.ToInt32(Request.QueryString["productlevel"])); level.InnerText = v_lvl.Nama; } else { level.InnerText = "Semua"; }


        // if (Convert.ToInt32(Request.QueryString["cabang"]) > 0) { var v_cab = rs.SingleOrDefault(p => p.ID == Convert.ToInt32(Request.QueryString["category"])); cabang.InnerText = v_cab.Nama; } else { cabang.InnerText = "Semua"; }

        report_datetime.InnerText = Str.TglJam(System.DateTime.Now);

    }
    //Display Table
    protected void fillTable(object sender, EventArgs e)
    {
        var rs = from design in db.ProductDesign
                 join order in db.ProductOrder on design.ID equals order.IDProductDesign
                 join karetDJ in db.KodeKaretDJ on order.ID equals karetDJ.IDProductOrder
                 join karetDetail in db.KodeKaret_Detail on karetDJ.ID equals karetDetail.IDKodeKaret
                 join receiveDJ in db.StockReceiveDJ on karetDetail.ID equals receiveDJ.Proto
                 select new
                 {
                     Nomor = karetDJ.Nomor,
                     Designer = design.HumanDesignerNama,
                     DataHuman = design.DataHuman,
                     ProductDesign_CharDesign = karetDJ.KodeKaretDJ_CharDesign,
                     ProductDesign_CharProduct = karetDJ.KodeKaretDJ_CharProduct,
                     ProductDesign_PricingSegmen = design.ProductDesign_PricingSegmen,
                     Approval = design.Approval,
                     Tgl = design.Tgl,
                     ImgPicture = design.ImgPicture
                 };



        string keyword = Request.QueryString["kw"];
        if (keyword != "") rs = rs.Where(p => p.Nomor == "" + keyword + "");
        int DesignCategory = Convert.ToInt32(Request.QueryString["designcategory"]);
        if (DesignCategory > 0) rs = rs.Where(p => p.ProductDesign_CharDesign.DesignCategory == DesignCategory);
        int DesignConcept = Convert.ToInt32(Request.QueryString["designconcept"]);
        if (DesignConcept > 0) rs = rs.Where(p => p.ProductDesign_CharDesign.DesignConcept == DesignConcept);
        int TargetAge = Convert.ToInt32(Request.QueryString["targetage"]);
        if (TargetAge > 0) rs = rs.Where(p => p.ProductDesign_CharDesign.TargetAge == TargetAge);
        int TargetGender = Convert.ToInt32(Request.QueryString["targetgender"]);
        if (TargetGender > 0) rs = rs.Where(p => p.ProductDesign_CharDesign.TargetGender == TargetGender);
        int ProductItem = Convert.ToInt32(Request.QueryString["productitem"]);
        if (ProductItem > 0) rs = rs.Where(p => p.ProductDesign_CharProduct.ProductItem == ProductItem);
        int ProductLevel = Convert.ToInt32(Request.QueryString["productlevel"]);
        if (ProductLevel > 0) rs = rs.Where(p => p.ProductDesign_CharProduct.ProductLevel == ProductLevel);
        int ProductCategory = Convert.ToInt32(Request.QueryString["productcategory"]);
        if (ProductCategory > 0) rs = rs.Where(p => p.ProductDesign_CharProduct.ProductCategory == ProductCategory);
        int Designer = Convert.ToInt32(Request.QueryString["designer"]);
        if (Designer > 0) rs = rs.Where(p => p.DataHuman.ID == Designer);

        int StoneDist = Convert.ToInt32(Request.QueryString["stonedistribution"]);
        if (StoneDist > 0) rs = rs.Where(p => p.ProductDesign_CharProduct.StoneDist == StoneDist);
        int ProductSegmen = Convert.ToInt32(Request.QueryString["segmen"]);
        if (ProductSegmen > 0) rs = rs.Where(p => p.ProductDesign_PricingSegmen.ProductSegmen == ProductSegmen);

        if (Request.QueryString["groupby"] == "1")
            rs = rs.Where(p => p.Approval != null);
        else if (Request.QueryString["groupby"] == "2")
            rs = rs.Where(p => p.Approval == null);
        if (Request.QueryString["dari"] != "" && Request.QueryString["sampai"] != "")
        {
            rs = rs.Where(p => p.Tgl >= Convert.ToDateTime(Request.QueryString["dari"]) && p.Tgl <= Convert.ToDateTime(Request.QueryString["sampai"]));
        }

        var rsg = rs.GroupBy(p => p.Nomor);

        if (rsg != null)
        {
            int index = 1;
            foreach (var r in rsg)
            {
                if (!Response.IsClientConnected) break;

                TableRow tr = new TableRow();
                TableCell td;

                td = new TableCell();
                td.Text = "<p>" + index++.ToString() + ".</p>";
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().Nomor;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().ProductDesign_CharProduct.CharProductCategory.Nama;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().ProductDesign_CharProduct.CharProductLevel.Nama;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().ProductDesign_CharProduct.CharProductItem.Nama;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().ProductDesign_CharProduct.CharStoneDist.Nama;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().ProductDesign_CharDesign.CharDesignCategory.Nama;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().ProductDesign_CharDesign.CharDesignConcept.Nama;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().ProductDesign_PricingSegmen.CharProductSegmen.Nama;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().ProductDesign_CharDesign.Naming;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.First().Designer;
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = r.Count().ToString();
                tr.Cells.Add(td);

                var spDJ = from design in db.ProductDesign
                           join order in db.ProductOrder on design.ID equals order.IDProductDesign
                           join karetDJ in db.KodeKaretDJ on order.ID equals karetDJ.IDProductOrder
                           join karetDetail in db.KodeKaret_Detail on karetDJ.ID equals karetDetail.IDKodeKaret
                           join receiveDJ in db.StockReceiveDJ on karetDetail.ID equals receiveDJ.Proto
                           join productDJ in db.StockProductDJ on receiveDJ.Nomor equals productDJ.Nomor
                           where karetDJ.Nomor == r.First().Nomor && productDJ.StatusPenjualan == 2
                           select new { Nomor = karetDJ.Nomor };

                td = new TableCell();
                td.Text = spDJ.Count().ToString();
                tr.Cells.Add(td);

                td = new TableCell();
                td.Text = "<p><img src=\"/Images.aspx?path=" + r.First().ImgPicture + "\" width=\"100\" /></p>";
                tr.Cells.Add(td);

                tb.Rows.Add(tr);
            }
        }
    }
}